//function initialize() { 
//        var xmlDoc 
//        var xslDoc 
//        xmlDoc = new ActiveXObject('Microsoft.XMLDOM') 
//        xmlDoc.async = false; 
//        xslDoc = new ActiveXObject('Microsoft.XMLDOM') 
//        xslDoc.async = false; 

//        xmlDoc.load("tree/tree.xml") 
//        xslDoc.load("tree/tree.xsl") 
//        folderTree.innerHTML = xmlDoc.documentElement.transformNode(xslDoc) 
//    } 
var xsl;
var xsltProcessor = new XSLTProcessor();
var myDOM;

var xmlDoc;

function initialize() {
    console.log("edge")
    // load the xslt file 
    var myXMLHTTPRequest = new XMLHttpRequest();
    myXMLHTTPRequest.open("GET", "tree/tree.xsl", false);
    myXMLHTTPRequest.send(null);

    xsl = myXMLHTTPRequest.responseXML;
    xsltProcessor.importStylesheet(xsl);

    // load the xml file 
    myXMLHTTPRequest = new XMLHttpRequest();
    myXMLHTTPRequest.open("GET", "tree/tree.xml", false);
    myXMLHTTPRequest.send(null);

    xmlDoc = myXMLHTTPRequest.responseXML;

    var fragment = xsltProcessor.transformToFragment(xmlDoc, document);

    document.getElementById("folderTree").textContent = "";

    myDOM = fragment;
    document.getElementById("folderTree").appendChild(fragment);
    const divs = document.querySelectorAll("div"); // newer browsers can do forEach here 
    for (var i = 0; i < divs.length; i++) collapse(divs[i]);
}



function LinkToForms(keyId, pageName) {

    console.log(keyId, pageName)

    if ((keyId != null && keyId != "") && (pageName != null && pageName != "")) {
        //This links the category/product information to the admin screens using it's primary key.; 
        parent.frameName2.location.href = pageName + '?PrimaryKeyID=' + keyId;

    }

    return true;
}

function clickOnEntity(entity) {

    LinkToForms(entity.getAttribute("keyId"), entity.getAttribute("linkPageName"));

    if (entity.open == "false") {
        expand(entity, true)
    }
    else {
        collapse(entity)
    }
    window.event.cancelBubble = true
}
function redirect(pageName) {
    //Redirect to new page in same window. 
    self.location.href = pageName;
}

function expand(entity) {
    var oImage, i;
    oImage = entity.querySelector(".image")
    oImage.src = entity.getAttribute('imageOpen');

    for (i = 0; i < entity.childNodes.length; i++) {
        if (entity.childNodes[i].tagName == "DIV") {
            entity.childNodes[i].style.display = "block"
        }
    }
    entity.open = "true"
}

function collapse(entity) {
    var oImage, i;

    oImage = entity.querySelector(".image")
    oImage.src = entity.getAttribute('image')

    // collapse and hide children 
    for (i = 0; i < entity.childNodes.length; i++) {
        if (entity.childNodes[i].tagName == "DIV") {
            if (entity.id != "folderTree") entity.childNodes[i].style.display = "none"
            collapse(entity.childNodes[i])
        }
    }
    entity.open = "false"

}

function expandAll(entity) {
    var oImage, i;

    expand(entity, false)

    // expand children 
    for (i = 0; i < entity.childNodes.length; i++) {
        if (entity.childNodes[i].tagName == "DIV") {
            expandAll(entity.childNodes[i])
        }
    }
}
window.addEventListener("load", initialize)


